<!DOCTYPE html>
<html lang="en-GB" prefix="og: http://ogp.me/ns#">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://symonmk.com/xmlrpc.php">

<title>Page not found - SYMON MUTHEMBA</title>

<!-- This site is optimized with the Yoast SEO plugin v7.2 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_GB" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - SYMON MUTHEMBA" />
<meta property="og:site_name" content="SYMON MUTHEMBA" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found - SYMON MUTHEMBA" />
<meta name="twitter:site" content="@SymonMK_" />
<script type='application/ld+json'>{"@context":"https:\/\/schema.org","@type":"Person","url":"http:\/\/symonmk.com\/","sameAs":["http:\/\/linkedin.com\/in\/symon-muthemba","https:\/\/twitter.com\/SymonMK_"],"@id":"#person","name":"Symon Muthemba"}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//s.gravatar.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="SYMON MUTHEMBA &raquo; Feed" href="http://symonmk.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="SYMON MUTHEMBA &raquo; Comments Feed" href="http://symonmk.com/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v7.0.4 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
	var mi_track_user = true;
	var disableStr = 'ga-disable-UA-113156242-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
	
	if ( mi_track_user ) {
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

		__gaTracker('create', 'UA-113156242-1', 'auto');
		__gaTracker('set', 'forceSSL', true);
		__gaTracker('require', 'displayfeatures');
		__gaTracker('require', 'linkid', 'linkid.js');
		__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
	} else {
		console.log( "" );
		(function() {
			/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
			var noopfn = function() {
				return null;
			};
			var noopnullfn = function() {
				return null;
			};
			var Tracker = function() {
				return null;
			};
			var p = Tracker.prototype;
			p.get = noopfn;
			p.set = noopfn;
			p.send = noopfn;
			var __gaTracker = function() {
				var len = arguments.length;
				if ( len === 0 ) {
					return;
				}
				var f = arguments[len-1];
				if ( typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function' ) {
					console.log( 'Not running function __gaTracker(' + arguments[0] + " ....) because you\'re not being tracked. ");
					return;
				}
				try {
					f.hitCallback();
				} catch (ex) {

				}
			};
			__gaTracker.create = function() {
				return new Tracker();
			};
			__gaTracker.getByName = noopnullfn;
			__gaTracker.getAll = function() {
				return [];
			};
			__gaTracker.remove = noopfn;
			window['__gaTracker'] = __gaTracker;
		})();
		}
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/symonmk.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.6"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-quicklatex-format-css'  href='http://symonmk.com/wp-content/plugins/wp-quicklatex/css/quicklatex-format.css?ver=4.9.6' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://symonmk.com/wp-content/themes/astrid/css/bootstrap/bootstrap.min.css?ver=1' type='text/css' media='all' />
<link rel='stylesheet' id='astrid-style-css'  href='http://symonmk.com/wp-content/themes/astrid/style.css?ver=4.9.6' type='text/css' media='all' />
<style id='astrid-style-inline-css' type='text/css'>
.site-header {position: fixed;}
.woocommerce .woocommerce-message:before,.woocommerce #payment #place_order,.woocommerce-page #payment #place_order,.woocommerce .cart .button, .woocommerce .cart input.button,.woocommerce-cart .wc-proceed-to-checkout a.checkout-button,.woocommerce #review_form #respond .form-submit input,.woocommerce a.button,.woocommerce div.product form.cart .button,.woocommerce .star-rating,.page-header .page-title .fa,.site-footer a:hover,.footer-info a:hover,.footer-widgets a:hover,.testimonial-title a:hover,.employee-title a:hover,.fact .fa,.service-title a:hover,.widget-area .widget a:hover,.entry-meta a:hover,.entry-footer a:hover,.entry-title a:hover,.comment-navigation a:hover,.posts-navigation a:hover,.post-navigation a:hover,.main-navigation a:hover,.main-navigation li.focus > a,a,a:hover,button,.button,input[type="button"],input[type="reset"],input[type="submit"] { color:#f7b733}
.social-menu-widget a,.woocommerce span.onsale,.woocommerce #payment #place_order:hover, .woocommerce-page #payment #place_order:hover,.woocommerce .cart .button:hover, .woocommerce .cart input.button:hover,.woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover,.woocommerce #review_form #respond .form-submit input:hover,.woocommerce div.product form.cart .button:hover,.woocommerce a.button:hover,.preloader-inner ul li,.progress-animate,button:hover,.button:hover,input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover { background-color:#f7b733}
.woocommerce .woocommerce-message,.woocommerce #payment #place_order,.woocommerce-page #payment #place_order,.woocommerce .cart .button, .woocommerce .cart input.button,.woocommerce-cart .wc-proceed-to-checkout a.checkout-button,.woocommerce #review_form #respond .form-submit input,.woocommerce a.button,.woocommerce div.product form.cart .button,.main-navigation li a::after,.main-navigation li a::before,button,.button,input[type="button"],input[type="reset"],input[type="submit"] { border-color:#f7b733}
.site-title a,.site-title a:hover { color:#ffffff}
.site-description { color:#ffffff}
.site-header,.site-header.header-scrolled { background-color:rgba(74,189,172,0.9)}
@media only screen and (max-width: 1024px) { .site-header.has-header,.site-header.has-video,.site-header.has-single,.site-header.has-shortcode { background-color:rgba(74,189,172,0.9)} }
body, .widget-area .widget, .widget-area .widget a { color:#595959}
.footer-widgets, .site-footer, .footer-info { background-color:#fc4a1a}
body {font-family: 'Droid Serif', serif;}
h1, h2, h3, h4, h5, h6, .fact .fact-number, .fact .fact-name, .site-title {font-family: 'Montserrat', sans-serif;}
.site-title { font-size:25px; }
.site-description { font-size:14px; }
h1 { font-size:36px; }
h2 { font-size:30px; }
h3 { font-size:24px; }
h4 { font-size:16px; }
h5 { font-size:14px; }
h6 { font-size:12px; }
body { font-size:14px; }

</style>
<link rel='stylesheet' id='astrid-body-fonts-css'  href='//fonts.googleapis.com/css?family=Droid+Serif%3A400&#038;ver=4.9.6' type='text/css' media='all' />
<link rel='stylesheet' id='astrid-headings-fonts-css'  href='//fonts.googleapis.com/css?family=Montserrat%3A700&#038;ver=4.9.6' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://symonmk.com/wp-content/themes/astrid/fonts/font-awesome.min.css?ver=4.9.6' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack_css-css'  href='http://symonmk.com/wp-content/plugins/jetpack/css/jetpack.css?ver=5.9' type='text/css' media='all' />
<script type='text/javascript' src='http://symonmk.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://symonmk.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"http:\/\/symonmk.com","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='http://symonmk.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js?ver=7.0.4'></script>
<script type='text/javascript' src='http://symonmk.com/wp-content/plugins/wp-quicklatex/js/wp-quicklatex-frontend.js?ver=1.0'></script>
<link rel='https://api.w.org/' href='http://symonmk.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://symonmk.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://symonmk.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.6" />

<link rel='dns-prefetch' href='//v0.wordpress.com'/>
<link rel='dns-prefetch' href='//widgets.wp.com'/>
<link rel='dns-prefetch' href='//s0.wp.com'/>
<link rel='dns-prefetch' href='//0.gravatar.com'/>
<link rel='dns-prefetch' href='//1.gravatar.com'/>
<link rel='dns-prefetch' href='//2.gravatar.com'/>
<link rel='dns-prefetch' href='//i0.wp.com'/>
<link rel='dns-prefetch' href='//i1.wp.com'/>
<link rel='dns-prefetch' href='//i2.wp.com'/>
<style type='text/css'>img#wpstats{display:none}</style><style type="text/css" id="custom-background-css">
body.custom-background { background-color: #dfdce3; }
</style>
<style type="text/css" id="syntaxhighlighteranchor"></style>
<link rel="icon" href="https://i1.wp.com/symonmk.com/wp-content/uploads/2018/01/symon-3.png?fit=32%2C32" sizes="32x32" />
<link rel="icon" href="https://i1.wp.com/symonmk.com/wp-content/uploads/2018/01/symon-3.png?fit=192%2C192" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://i1.wp.com/symonmk.com/wp-content/uploads/2018/01/symon-3.png?fit=180%2C180" />
<meta name="msapplication-TileImage" content="https://i1.wp.com/symonmk.com/wp-content/uploads/2018/01/symon-3.png?fit=270%2C270" />
</head>

<body class="error404 custom-background hfeed">

<div class="preloader">
<div class="preloader-inner">
	<ul><li></li><li></li><li></li><li></li><li></li><li></li></ul>
</div>
</div>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

	<header id="masthead" class="site-header " role="banner">
		<div class="container">
			<div class="site-branding col-md-4 col-sm-6 col-xs-12">
				<p class="site-title"><a href="http://symonmk.com/" rel="home">SYMON MUTHEMBA</a></p><p class="site-description">Let&#039;s Get Technical</p>			</div>
			<div class="btn-menu col-md-8 col-sm-6 col-xs-12"><i class="fa fa-navicon"></i></div>
			<nav id="mainnav" class="main-navigation col-md-8 col-sm-6 col-xs-12" role="navigation">
				<div class="menu-main-navigation-container"><ul id="primary-menu" class="menu"><li id="menu-item-660" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-660"><a href="http://symonmk.com/">Home</a></li>
<li id="menu-item-659" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-659"><a href="http://symonmk.com/blog/">Blog</a></li>
<li id="menu-item-716" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-716"><a href="http://symonmk.com/resume/">Resume</a></li>
<li id="menu-item-664" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-664"><a href="http://symonmk.com/contact/">Contact</a></li>
</ul></div>			</nav><!-- #site-navigation -->
		</div>
	</header><!-- #masthead -->

			<div class="header-clone"></div>
		

				
	
	<div id="content" class="site-content">
		<div class="container">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

					<form role="search" method="get" class="search-form" action="http://symonmk.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>		<div class="widget widget_recent_entries">		<h2 class="widgettitle">Recent Posts</h2>		<ul>
											<li>
					<a href="http://symonmk.com/fpgas-digital-communications/">FPGAs for Innovating Digital Communication Interfaces</a>
									</li>
											<li>
					<a href="http://symonmk.com/ultimate-broadcast-facility/">The Ultimate Production and Transmission Broadcast Facility</a>
									</li>
											<li>
					<a href="http://symonmk.com/off-grid-communications-for-the-masses-smart-metering/">Off-Grid Communications For The Masses: Smart Metering</a>
									</li>
											<li>
					<a href="http://symonmk.com/design-wireless-systems/">Simplification in Design of Wireless Systems: 5 Useful Steps</a>
									</li>
											<li>
					<a href="http://symonmk.com/intro-computer-vision/">How Computers &#8216;See&#8217; and Add Value to Your Media: An Intro to Computer Vision</a>
									</li>
					</ul>
		</div>
					<div class="widget widget_archive"><h2 class="widgettitle">Archives</h2><p>Try looking in the monthly archives. 🙂</p>		<label class="screen-reader-text" for="archives-dropdown--1">Archives</label>
		<select id="archives-dropdown--1" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'>
			
			<option value="">Select Month</option>
				<option value='http://symonmk.com/2018/05/'> May 2018 </option>
	<option value='http://symonmk.com/2018/04/'> April 2018 </option>
	<option value='http://symonmk.com/2018/03/'> March 2018 </option>
	<option value='http://symonmk.com/2018/02/'> February 2018 </option>
	<option value='http://symonmk.com/2018/01/'> January 2018 </option>
	<option value='http://symonmk.com/2017/12/'> December 2017 </option>
	<option value='http://symonmk.com/2017/11/'> November 2017 </option>
	<option value='http://symonmk.com/2017/09/'> September 2017 </option>
	<option value='http://symonmk.com/2017/08/'> August 2017 </option>
	<option value='http://symonmk.com/2017/07/'> July 2017 </option>
	<option value='http://symonmk.com/2017/05/'> May 2017 </option>
	<option value='http://symonmk.com/2017/04/'> April 2017 </option>
	<option value='http://symonmk.com/2017/03/'> March 2017 </option>

		</select>
		</div>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->


		</div>
	</div><!-- #content -->

	<div class="footer-wrapper">
				
				
		<footer id="colophon" class="site-footer" role="contentinfo">	
			<div class="site-info container">
				<nav id="footernav" class="footer-navigation" role="navigation">
					<div id="footer-menu" class="menu"><ul>
<li class="page_item page-item-6"><a href="http://symonmk.com/">About Me</a></li>
<li class="page_item page-item-9 current_page_parent"><a href="http://symonmk.com/blog/">Blog</a></li>
<li class="page_item page-item-11"><a href="http://symonmk.com/contact/">Contact</a></li>
<li class="page_item page-item-710"><a href="http://symonmk.com/resume/">Resume</a></li>
</ul></div>
				</nav><!-- #site-navigation -->
				<div class="site-copyright">
					<a href="https://wordpress.org/">Powered by WordPress</a><span class="sep"> | </span>Theme: <a href="http://athemes.com/theme/astrid" rel="designer">Astrid</a> by aThemes.				</div>
			</div><!-- .site-info -->
		</footer><!-- #colophon -->
	</div>

</div><!-- #page -->

	<div style="display:none">
	</div>
<script type='text/javascript' src='http://symonmk.com/wp-content/plugins/jetpack/_inc/build/photon/photon.min.js?ver=20130122'></script>
<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201827'></script>
<script type='text/javascript' src='http://s.gravatar.com/js/gprofiles.js?ver=2018Julaa'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var WPGroHo = {"my_hash":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://symonmk.com/wp-content/plugins/jetpack/modules/wpgroho.js?ver=4.9.6'></script>
<script type='text/javascript' src='http://symonmk.com/wp-content/themes/astrid/js/main.js?ver=4.9.6'></script>
<script type='text/javascript' src='http://symonmk.com/wp-content/themes/astrid/js/scripts.min.js?ver=4.9.6'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://symonmk.com/wp-content/themes/astrid/js/html5shiv.js?ver=4.9.6'></script>
<![endif]-->
<script type='text/javascript' src='http://symonmk.com/wp-includes/js/wp-embed.min.js?ver=4.9.6'></script>
<script type='text/javascript' src='https://stats.wp.com/e-201827.js' async='async' defer='defer'></script>
<script type='text/javascript'>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:5.9',blog:'141419617',post:'0',tz:'3',srv:'symonmk.com'} ]);
	_stq.push([ 'clickTrackerInit', '141419617', '0' ]);
</script>

</body>
</html>
